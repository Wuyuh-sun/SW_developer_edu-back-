gsap.to(".box", { left: 500, duration: 1 });
