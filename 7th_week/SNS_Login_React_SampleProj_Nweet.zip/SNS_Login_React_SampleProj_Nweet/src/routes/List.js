const List = () => {
  return <span>List ...</span>;
};

export default List;
