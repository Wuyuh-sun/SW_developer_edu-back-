const EditProfile = () => <span>EditProfile</span>

export default EditProfile;