package com.jojoldu.book.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo0ApplicationTests {

	@Test
	void contextLoads() {
	}

}
